# Remodel_MrMel VR Builder Assistant

This is a complete 8-phase assistant workflow that takes a narrated video walkthrough and transforms it into an immersive VR-ready 3D layout.

## 🚀 Live Phases
1. Video Upload & Whisper Transcription
2. GPT Zone + Layout Command Extraction
3. Frame Snapshot Generator
4. 2D Static Blueprint SVG Renderer
5. Feedback + User Confirmation
6. 3D Layout Generator (GLB)
7. Final Confirmation Gate
8. VR Bundle Exporter

## 🧠 How to Use

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Launch the assistant
```bash
streamlit run streamlit_app.py
```

### 3. Navigate phases
Each tab represents one clean, reusable assistant capsule. Upload your video → transcribe → confirm → render → export.

## 🗃️ File Organization

- `streamlit_tabs/` – UI tabs for each phase
- `core_modules/` – All logic units used across phases
- `layout_test/` – Stores user uploads, snapshots, GLB files, and transcripts

## 🧪 Mutation-Ready
Each file in this repo is zipped as a `.gptpkg`, version-locked, and mutation-traceable.

---

© Built for [Dad] by [Michael] using GPT-4 mutation cycles.
