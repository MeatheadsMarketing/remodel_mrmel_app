# PHASE_1_FILE: Handles video upload, triggers audio extraction and transcription
# Origin: Blueprint Phase 1 — VIDEO + VOICE INTAKE
# Role: Streamlit UI tab for dad to upload a walkthrough video and trigger processing chain

import streamlit as st
import os
from core_modules import video_format_converter, audio_splitter, whisper_transcriber

st.set_page_config(page_title="🎥 Upload Walkthrough Video", layout="centered")

st.title("📼 Step 1: Upload Your Walkthrough Video")
st.write("Please upload your video tour of the property. Make sure it includes your voice explaining each room or area.")

uploaded_file = st.file_uploader("Upload video file (.mp4, .mov, .avi)", type=["mp4", "mov", "avi"])

if uploaded_file:
    # Save uploaded file
    upload_dir = "layout_test/input_video"
    os.makedirs(upload_dir, exist_ok=True)
    input_path = os.path.join(upload_dir, uploaded_file.name)

    with open(input_path, "wb") as f:
        f.write(uploaded_file.read())

    st.success("✅ Video uploaded successfully.")

    # Convert format
    converted_path = video_format_converter.convert(input_path)
    st.info("🔄 Format conversion complete.")

    # Extract audio
    audio_path = audio_splitter.extract(converted_path)
    st.info("🎙️ Audio extracted.")

    # Transcribe
    transcript_path = whisper_transcriber.transcribe(audio_path)
    st.success("📝 Transcription complete.")

    st.markdown("---")
    st.markdown("### 📄 Transcript Preview:")
    with open(transcript_path, "r") as f:
        st.code(f.read(), language="json")
